 "intents" [{
         "tag": "greeting",
         "patterns": ["Hi", "How are you", "Is anyone there?", "Hello", "Good day", "Whats up", "Hey", "greetings"],
         "responses": ["Hello!", "Good to see you again!", "Hi there, how can I help?"],
         "context_set": ""
     },
     {
         "tag": "goodbye",
         "patterns": ["cya", "See you later", "Goodbye", "I am Leaving", "Have a Good day", "bye", "cao", "see ya"],
         "responses": ["Sad to see you go :(", "Talk to you later", "Goodbye!"],
         "context_set": ""
     },
     {
         "tag": "stocks",
         "patterns": ["I'm heartbroken", "I'm sad", "Tell me you love me", "What should I do next?"],
         "responses": ["Sometimes, letting someone go doesn't mean you're weak But it shows that we are strong enough to let him go.",
             "Don't cry when the sun goes down. because tears will make us unable to see the thousands of stars that are about to appear",
             "Love is like a glass, sometimes letting it break It is better than trying to pick it up again when your heart hurts.",
             "No matter who hurts your heart And no matter how long it takes to heal your heart, your friends will always be by your side."
         ],
         "context_set": ""
     }
 ]