.. include:: ../../neps/ufunc-overrides.rst
